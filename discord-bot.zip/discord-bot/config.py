import os
import copy
import logging

import yaml
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

DEFAULTS = {
    "personality": "あなたはフレンドリーなAIアシスタントです。",
    "openai": {"model": "gpt-4o", "max_tokens": 500},
    "search": {
        "mode": "normal",
        "category": "auto",
        "region": "wt-wt",
        "safesearch": "moderate",
        "timelimit": None,
        "max_results": 8,
        "max_pages": 3,
        "fetch_timeout_seconds": 6,
        "max_chars_per_page": 2500,
        "max_total_chars": 9000,
        "deep_extra_queries": 2,
    },
    "spontaneous": {
        "enabled": True,
        "threshold": 7.0,
        "cooldown_seconds": 300,
        "eval_interval": 5,
        "min_message_length": 6,
        "allow_tools": False,
    },
    "memory": {
        "buffer_size": 30,
        "context_size_mention": 10,
        "context_size_spontaneous": 20,
    },
    "allowed_channels": [],
}

_config = None


def _deep_merge(base: dict, override: dict) -> dict:
    """baseをoverrideで上書きマージする（ネスト対応）"""
    result = copy.deepcopy(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def load_config(config_path: str = "config.yaml") -> dict:
    """config.yamlを読み込み、デフォルト値とマージして返す"""
    global _config

    load_dotenv()

    if not os.environ.get("DISCORD_TOKEN"):
        raise ValueError("DISCORD_TOKEN が環境変数に設定されていません。.envファイルを確認してください。")
    if not os.environ.get("OPENAI_API_KEY"):
        raise ValueError("OPENAI_API_KEY が環境変数に設定されていません。.envファイルを確認してください。")

    file_config = {}
    if os.path.exists(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            file_config = yaml.safe_load(f) or {}
        logger.info("設定ファイルを読み込みました: %s", config_path)
    else:
        logger.warning("設定ファイルが見つかりません: %s（デフォルト値を使用）", config_path)

    _config = _deep_merge(DEFAULTS, file_config)

    env_model = (os.environ.get("OPENAI_MODEL") or "").strip()
    if env_model:
        _config.setdefault("openai", {})
        _config["openai"]["model"] = env_model
        logger.info("環境変数 OPENAI_MODEL によりモデルを上書き: %s", env_model)

    return _config


def get_config() -> dict:
    """読み込み済みの設定を返す（load_config未呼び出し時はエラー）"""
    if _config is None:
        raise RuntimeError("設定が読み込まれていません。先にload_config()を呼び出してください。")
    return _config
