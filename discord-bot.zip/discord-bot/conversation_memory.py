from collections import defaultdict, deque
from datetime import datetime


class ConversationMemory:
    def __init__(self, buffer_size: int = 30):
        """チャンネルごとの会話履歴を管理"""
        self.buffer_size = buffer_size
        self.bot_name = "AI Assistant"
        self.bot_user_id: int | None = None
        self._buffers: dict[int, deque] = defaultdict(
            lambda: deque(maxlen=self.buffer_size)
        )

    def add_message(self, channel_id: int, author: str, content: str, timestamp: datetime, author_id: int | None = None) -> None:
        """メッセージを履歴に追加"""
        self._buffers[channel_id].append({
            "author": author,
            "author_id": author_id,
            "content": content,
            "timestamp": timestamp,
        })

    def clear(self, channel_id: int) -> int:
        """指定チャンネルの会話履歴を消去する。消去した件数を返す。"""
        count = len(self._buffers[channel_id])
        self._buffers[channel_id].clear()
        return count

    def get_recent(self, channel_id: int, count: int = 10) -> list[dict]:
        """直近N件のメッセージを返す。各要素は {author, content, timestamp}"""
        buf = self._buffers[channel_id]
        items = list(buf)
        return items[-count:] if len(items) > count else items

    def format_for_api(self, channel_id: int, count: int = 10) -> list[dict]:
        """OpenAI API用のメッセージリスト形式に変換。

        ボット自身の発言は role="assistant" にする。
        それ以外は role="user" で "author: content" 形式。
        """
        recent = self.get_recent(channel_id, count)
        messages = []
        for msg in recent:
            if (self.bot_user_id and msg.get("author_id") == self.bot_user_id) or msg["author"] == self.bot_name:
                messages.append({
                    "role": "assistant",
                    "content": msg["content"],
                })
            else:
                messages.append({
                    "role": "user",
                    "content": f"{msg['author']}: {msg['content']}",
                })
        return messages
