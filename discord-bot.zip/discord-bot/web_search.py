import json
import logging
import re
from html import unescape
from urllib import error, request

from ddgs import DDGS

from config import get_config

logger = logging.getLogger(__name__)
DEFAULT_SEARCH_CONFIG = {
    "mode": "normal",
    "category": "auto",
    "region": "wt-wt",
    "safesearch": "moderate",
    "timelimit": None,
    "max_results": 8,
    "max_pages": 3,
    "fetch_timeout_seconds": 6,
    "max_chars_per_page": 2500,
    "max_total_chars": 9000,
    "deep_extra_queries": 2,
}


def _deep_merge(base: dict, override: dict) -> dict:
    merged = dict(base)
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _load_search_config() -> dict:
    try:
        cfg = get_config()
    except Exception:
        return dict(DEFAULT_SEARCH_CONFIG)

    custom = cfg.get("search", {})
    if not isinstance(custom, dict):
        return dict(DEFAULT_SEARCH_CONFIG)

    return _deep_merge(DEFAULT_SEARCH_CONFIG, custom)

SEARCH_TOOL_DEFINITION = {
    "type": "function",
    "function": {
        "name": "web_search",
        "description": "Web検索を実行して最新の情報を取得する。ユーザーの質問に答えるために最新情報が必要な場合に使う。",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "検索クエリ",
                },
                "mode": {
                    "type": "string",
                    "enum": ["quick", "normal", "deep"],
                    "description": "検索の深さ。quickは検索結果のみ、normal/deepはページ本文を取得する。",
                },
                "category": {
                    "type": "string",
                    "enum": ["auto", "text", "news"],
                    "description": "検索カテゴリ。autoは質問内容から自動判定。",
                },
            },
            "required": ["query"],
        },
    },
}


def _is_news_query(query: str) -> bool:
    q = query.lower()
    keywords = (
        "latest",
        "today",
        "breaking",
        "news",
        "速報",
        "最新",
        "今日",
        "発表",
        "リリース",
        "価格",
        "株価",
        "決算",
        "スコア",
        "天気",
        "選挙",
    )
    return any(k in q for k in keywords)


def _resolve_categories(category: str, query: str) -> list[str]:
    if category in ("text", "news"):
        return [category]
    if _is_news_query(query):
        return ["news", "text"]
    return ["text"]


def _expand_queries_for_deep(query: str, extra_count: int) -> list[str]:
    variants = [
        f"{query} 公式情報",
        f"{query} 詳細",
        f"{query} 解説",
        f"{query} source",
    ]
    if extra_count <= 0:
        return [query]
    return [query, *variants[:extra_count]]


def _run_ddgs_search(
    query: str,
    category: str,
    max_results: int,
    region: str,
    safesearch: str,
    timelimit: str | None,
) -> list[dict]:
    with DDGS() as ddgs:
        if category == "news":
            return list(
                ddgs.news(
                    query,
                    max_results=max_results,
                    region=region,
                    safesearch=safesearch,
                    timelimit=timelimit,
                )
            )
        return list(
            ddgs.text(
                query,
                max_results=max_results,
                region=region,
                safesearch=safesearch,
                timelimit=timelimit,
            )
        )


def _extract_text_from_html(html: str, max_chars: int) -> str:
    # ノイズ要素を先に除去してからタグを落とし、最低限の本文を抽出する。
    cleaned = re.sub(r"(?is)<(script|style|noscript|svg|canvas).*?>.*?</\1>", " ", html)
    cleaned = re.sub(r"(?i)<br\s*/?>", "\n", cleaned)
    cleaned = re.sub(r"(?i)</(p|div|li|h1|h2|h3|h4|h5|h6|tr|section|article)>", "\n", cleaned)
    cleaned = re.sub(r"(?is)<[^>]+>", " ", cleaned)
    cleaned = unescape(cleaned)

    lines = [re.sub(r"\s+", " ", line).strip() for line in cleaned.splitlines()]
    lines = [line for line in lines if line]
    text = "\n".join(lines)
    return text[:max_chars].strip()


def _fetch_page_text(url: str, timeout_seconds: int, max_chars: int) -> str:
    if not url:
        return ""

    req = request.Request(
        url,
        headers={
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0 Safari/537.36"
            )
        },
    )
    try:
        with request.urlopen(req, timeout=timeout_seconds) as res:
            content_type = (res.headers.get("Content-Type") or "").lower()
            if "text/html" not in content_type:
                return ""
            raw = res.read(max(8192, max_chars * 6))
            charset = res.headers.get_content_charset() or "utf-8"
            html = raw.decode(charset, errors="ignore")
            return _extract_text_from_html(html, max_chars=max_chars)
    except (error.URLError, ValueError, TimeoutError):
        return ""
    except Exception:
        logger.exception("ページ本文取得に失敗しました: %s", url)
        return ""


def _normalize_result(result: dict) -> dict:
    url = result.get("href") or result.get("url") or ""
    return {
        "title": result.get("title", ""),
        "snippet": result.get("body", ""),
        "url": url,
        "date": result.get("date", ""),
        "source": result.get("source", ""),
    }


def _dedup_results(results: list[dict]) -> list[dict]:
    seen = set()
    unique = []
    for r in results:
        key = r.get("url") or r.get("title")
        if not key or key in seen:
            continue
        seen.add(key)
        unique.append(r)
    return unique


def web_search(
    query: str,
    mode: str = "normal",
    category: str = "auto",
    max_results: int | None = None,
    settings: dict | None = None,
) -> str:
    """DuckDuckGoで検索し、必要に応じてページ本文も取得して返す。"""
    cfg = _deep_merge(DEFAULT_SEARCH_CONFIG, settings or {})
    if max_results is None:
        max_results = int(cfg["max_results"])

    max_results = max(1, int(max_results))
    max_pages = max(0, int(cfg["max_pages"]))
    timeout_seconds = max(1, int(cfg["fetch_timeout_seconds"]))
    max_chars_per_page = max(200, int(cfg["max_chars_per_page"]))
    max_total_chars = max(1000, int(cfg["max_total_chars"]))
    deep_extra_queries = max(0, int(cfg["deep_extra_queries"]))
    region = str(cfg["region"])
    safesearch = str(cfg["safesearch"])
    timelimit = cfg["timelimit"]

    mode = (mode or "normal").lower()
    if mode not in ("quick", "normal", "deep"):
        mode = "normal"

    category = (category or "auto").lower()
    if category not in ("auto", "text", "news"):
        category = "auto"

    try:
        categories = _resolve_categories(category, query)
        queries = (
            _expand_queries_for_deep(query, deep_extra_queries) if mode == "deep" else [query]
        )

        raw_results = []
        for q in queries:
            for c in categories:
                try:
                    found = _run_ddgs_search(
                        query=q,
                        category=c,
                        max_results=max_results,
                        region=region,
                        safesearch=safesearch,
                        timelimit=timelimit,
                    )
                except Exception as exc:
                    logger.warning("検索失敗 query=%s category=%s: %s", q, c, exc)
                    continue
                raw_results.extend(_normalize_result(item) for item in found)

        results = _dedup_results(raw_results)
        if results:
            results = results[:max_results]

        if not results:
            return "検索結果が見つかりませんでした。"

        do_fetch_content = mode in ("normal", "deep") and max_pages > 0
        total_content_chars = 0

        lines = [
            f"検索クエリ: {query}",
            f"検索モード: {mode}",
            f"カテゴリ: {', '.join(categories)}",
            f"ヒット件数: {len(results)}",
            "",
        ]
        for idx, r in enumerate(results, start=1):
            title = r.get("title", "")
            snippet = r.get("snippet", "")
            url = r.get("url", "")
            date = r.get("date", "")
            source = r.get("source", "")

            detail = ""
            if do_fetch_content and idx <= max_pages and url:
                remain = max_total_chars - total_content_chars
                if remain > 0:
                    fetched = _fetch_page_text(
                        url,
                        timeout_seconds=timeout_seconds,
                        max_chars=min(max_chars_per_page, remain),
                    )
                    if fetched:
                        detail = fetched
                        total_content_chars += len(detail)

            lines.append(f"[{idx}] {title}")
            if source:
                lines.append(f"ソース: {source}")
            if date:
                lines.append(f"日付: {date}")
            lines.append(f"URL: {url}")
            if snippet:
                lines.append(f"スニペット: {snippet}")
            if detail:
                lines.append(f"本文抜粋: {detail}")
            lines.append("")

        return "\n".join(lines).strip()
    except Exception as e:
        logger.exception("Web検索中にエラーが発生しました")
        return f"検索エラー: {e}"


def execute_tool_call(function_name: str, arguments: str) -> str:
    """ツール呼び出しを実行して結果を返す。"""
    if function_name == "web_search":
        args = json.loads(arguments)
        query = args.get("query", "")
        mode = args.get("mode", "")
        category = args.get("category", "")
        search_settings = _load_search_config()

        logger.info("Web検索実行: %s", query)
        return web_search(
            query=query,
            mode=mode or search_settings["mode"],
            category=category or search_settings["category"],
            max_results=search_settings["max_results"],
            settings=search_settings,
        )

    return f"Unknown tool: {function_name}"
