# Discord AIボット

Discordサーバー用のフレンドリーなAIアシスタントボットです。

## 機能

- **メンション応答**: ボットに@メンションすると、会話の文脈を踏まえて返答します
- **自発応答**: サーバーの会話を監視し、助言できる場面で自ら発言します（頻度は設定で調整可能）
- **ウェブ検索（段階検索）**: `quick / normal / deep` の検索深度で、必要に応じてページ本文まで取得します

## 必要なもの

- Python 3.10以上
- Discord Bot Token（[Developer Portal](https://discord.com/developers/applications)で取得）
- OpenAI API Key（[OpenAI](https://platform.openai.com/api-keys)で取得）

## セットアップ

### 1. 依存パッケージのインストール

```bash
pip install -r requirements.txt
```

### 2. 環境変数の設定

`.env.example` をコピーして `.env` を作成し、トークンを設定します。

```bash
cp .env.example .env
```

`.env` を編集:

```
DISCORD_TOKEN=あなたのDiscord Botトークン
OPENAI_API_KEY=あなたのOpenAI APIキー
OPENAI_MODEL=gpt-4o
```

`OPENAI_MODEL` を設定すると、`config.yaml` の `openai.model` より優先して使用されます。

### 3. Discord Developer Portal での設定

1. [Developer Portal](https://discord.com/developers/applications) でアプリケーションを作成
2. 「Bot」セクションで Bot を作成し、トークンをコピー
3. **Privileged Gateway Intents** で以下を有効化:
   - `MESSAGE CONTENT INTENT`（必須）
   - `SERVER MEMBERS INTENT`
4. 「OAuth2 → URL Generator」でボットの招待URLを生成
   - Scopes: `bot`
   - Bot Permissions: `Send Messages`, `Read Message History`
5. 生成されたURLでボットをサーバーに招待

### 4. 起動

```bash
python bot.py
```

## 設定（config.yaml）

| 項目 | 説明 | デフォルト |
|------|------|-----------|
| `personality` | ボットの性格（システムプロンプト） | フレンドリーなAI |
| `openai.model` | 使用するOpenAIモデル | `gpt-4o` |
| `openai.max_tokens` | 最大トークン数 | `500` |
| `search.mode` | 検索深度（`quick`/`normal`/`deep`） | `normal` |
| `search.category` | 検索カテゴリ（`auto`/`text`/`news`） | `auto` |
| `search.max_results` | 返却する検索結果の最大件数 | `8` |
| `search.max_pages` | 本文取得する最大ページ数 | `3` |
| `spontaneous.enabled` | 自発応答の有効/無効 | `true` |
| `spontaneous.threshold` | 参加判定スコアの閾値（0〜10、高いほど控えめ） | `7.0` |
| `spontaneous.cooldown_seconds` | 同一チャンネルでの自発応答の最小間隔（秒） | `300` |
| `spontaneous.eval_interval` | 何メッセージごとに参加判定するか | `5` |
| `spontaneous.min_message_length` | 評価対象の最小メッセージ長 | `6` |
| `spontaneous.allow_tools` | 自発応答でもweb検索などのツールを使うか | `false` |
| `memory.buffer_size` | チャンネルごとの保持メッセージ数 | `30` |
| `memory.context_size_mention` | メンション応答時に渡す履歴数 | `10` |
| `memory.context_size_spontaneous` | 自発応答時に渡す履歴数 | `20` |
| `allowed_channels` | 対象チャンネルIDのリスト（空なら全チャンネル） | `[]` |

### 自発応答のチューニング

- **ボットの発言頻度を下げたい**: `threshold` を上げる（例: `8.0` → `9.0`）、`cooldown_seconds` を増やす
- **ボットの発言頻度を上げたい**: `threshold` を下げる（例: `7.0` → `5.0`）、`eval_interval` を減らす
- **自発応答を完全に無効化**: `spontaneous.enabled` を `false` に設定

## トラブルシューティング

| 問題 | 解決策 |
|------|--------|
| `DISCORD_TOKEN が環境変数に設定されていません` | `.env` ファイルを作成し、トークンを設定してください |
| ボットがメッセージに反応しない | Developer Portal で Message Content Intent を有効化してください |
| `openai.AuthenticationError` | OpenAI API Keyが正しいか確認してください |
| ボットがオフラインのまま | Discord Bot Tokenが正しいか確認してください |
| 自発応答が発生しない | `threshold` を下げるか、`eval_interval` を `1` にしてテストしてください |
