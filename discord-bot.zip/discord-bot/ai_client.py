import logging
import re
import time
from typing import Callable

import openai
from openai import OpenAI

logger = logging.getLogger(__name__)

MAX_TOOL_ROUNDS = 3


class AIClient:
    def __init__(self, api_key: str, model: str = "gpt-4o", max_tokens: int = 500):
        """OpenAIクライアントを初期化"""
        self.client = OpenAI(api_key=api_key)
        self.model = model
        self.max_tokens = max_tokens
        self._token_param_name = "max_tokens"

    def _log_usage(self, response) -> None:
        usage = getattr(response, "usage", None)
        prompt_tokens = getattr(usage, "prompt_tokens", 0)
        completion_tokens = getattr(usage, "completion_tokens", 0)
        total_tokens = getattr(usage, "total_tokens", 0)
        model_name = getattr(response, "model", self.model)
        logger.info(
            "OpenAI API success model=%s tokens(prompt=%s completion=%s total=%s)",
            model_name,
            prompt_tokens,
            completion_tokens,
            total_tokens,
        )

    def _call_with_retry(self, messages: list[dict], tools: list[dict] | None = None):
        retryable_errors = (
            openai.RateLimitError,
            openai.APITimeoutError,
            openai.APIConnectionError,
        )
        delays = [1, 2, 4]
        last_error = None

        for attempt in range(len(delays) + 1):
            kwargs = self._build_request_kwargs(messages, tools)
            try:
                response = self.client.chat.completions.create(**kwargs)
                self._log_usage(response)
                return response
            except openai.BadRequestError as exc:
                # モデル側がトークン上限パラメータ名を要求する場合に自動で切り替える。
                if self._switch_token_param_if_needed(exc):
                    logger.warning(
                        "モデル=%s の要求に合わせてトークン上限パラメータを %s に切り替えて再試行します",
                        self.model,
                        self._token_param_name,
                    )
                    continue
                raise
            except retryable_errors as exc:
                last_error = exc
                if attempt == len(delays):
                    break
                delay = delays[attempt]
                logger.warning(
                    "OpenAI API call failed (attempt %s/%s). Retrying in %s seconds: %s",
                    attempt + 1,
                    len(delays) + 1,
                    delay,
                    exc,
                )
                time.sleep(delay)

        raise last_error

    def _build_request_kwargs(self, messages: list[dict], tools: list[dict] | None) -> dict:
        kwargs = {
            "model": self.model,
            "messages": messages,
            self._token_param_name: self.max_tokens,
        }
        if tools:
            kwargs["tools"] = tools
        return kwargs

    def _switch_token_param_if_needed(self, exc: Exception) -> bool:
        error_text = str(exc).lower()
        if "unsupported parameter" not in error_text:
            return False

        if "'max_tokens'" in error_text and self._token_param_name != "max_completion_tokens":
            self._token_param_name = "max_completion_tokens"
            return True

        if "'max_completion_tokens'" in error_text and self._token_param_name != "max_tokens":
            self._token_param_name = "max_tokens"
            return True

        return False

    def generate_response(
        self,
        system_prompt: str,
        messages: list[dict],
        tools: list[dict] | None = None,
        tool_executor: Callable[[str, str], str] | None = None,
    ) -> str:
        """Chat Completions APIを呼び出して応答を生成する。

        Args:
            system_prompt: システムプロンプト（ボットの性格）
            messages: OpenAI API形式のメッセージリスト
                      [{"role": "user"/"assistant", "content": "..."}]
            tools: ツール定義のリスト（Noneならツール無効）
            tool_executor: ツール実行関数 (function_name, arguments_json) -> result_str

        Returns:
            生成された応答テキスト

        Raises:
            Exception: API呼び出しが3回リトライ後も失敗した場合
        """
        api_messages = [{"role": "system", "content": system_prompt}, *messages]

        for _ in range(MAX_TOOL_ROUNDS):
            response = self._call_with_retry(api_messages, tools=tools)
            choice = response.choices[0]

            # ツール呼び出しがなければ最終応答
            if choice.finish_reason != "tool_calls" or not choice.message.tool_calls:
                content = choice.message.content
                return (content or "").strip()

            # ツール呼び出しを実行し、結果をメッセージに追加
            api_messages.append(choice.message)
            for tool_call in choice.message.tool_calls:
                if tool_executor:
                    try:
                        result = tool_executor(
                            tool_call.function.name,
                            tool_call.function.arguments,
                        )
                    except Exception as exc:
                        logger.warning("ツール実行エラー: %s: %s", tool_call.function.name, exc)
                        result = f"Tool error: {exc}"
                else:
                    result = f"No executor for tool: {tool_call.function.name}"
                api_messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "content": result,
                })
                logger.info("ツール実行: %s -> %d文字の結果", tool_call.function.name, len(result))

        # ループ上限に達した場合、最後のレスポンスからコンテンツを返す
        content = response.choices[0].message.content
        return (content or "").strip()

    def evaluate_relevance(self, messages: list[dict], bot_description: str) -> float:
        """会話への参加判定スコアを返す。

        Args:
            messages: OpenAI API形式のメッセージリスト
            bot_description: ボットの説明文

        Returns:
            0.0〜10.0のスコア。パース失敗時は0.0を返す
        """
        evaluator_prompt = (
            "あなたはDiscordサーバーのAIアシスタントです。\n"
            "以下の会話を読んで、あなたが参加すべきかを判定してください。\n"
            "\n"
            f"あなたの説明:\n{bot_description}\n"
            "\n"
            "判定基準：\n"
            "- 技術的な質問や困りごとがある → 高スコア\n"
            "- あなたの知識で助言できる内容がある → 高スコア\n"
            "- 雑談で盛り上がっている → 低スコア（邪魔しない）\n"
            "- すでに解決済みの話題 → 低スコア\n"
            "\n"
            "0〜10の数字のみで回答してください。"
        )

        api_messages = [{"role": "system", "content": evaluator_prompt}, *messages]
        response = self._call_with_retry(api_messages)
        content = (response.choices[0].message.content or "").strip()

        matched = re.search(r"\d+(?:\.\d+)?", content)
        if not matched:
            return 0.0

        try:
            score = float(matched.group(0))
        except ValueError:
            return 0.0

        if score < 0.0 or score > 10.0:
            return 0.0

        return score
