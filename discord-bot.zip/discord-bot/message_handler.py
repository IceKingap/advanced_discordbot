import asyncio
import logging
import time
from collections import defaultdict

import discord

from ai_client import AIClient
from conversation_memory import ConversationMemory
from config import get_config
from persistent_memory import (
    PersistentMemory,
    SAVE_INSTRUCTION_TOOL,
    SAVE_MEMORY_TOOL,
    execute_memory_tool,
)
from web_search import SEARCH_TOOL_DEFINITION, execute_tool_call as execute_web_search

logger = logging.getLogger(__name__)

DISCORD_MAX_LENGTH = 2000


ALL_TOOLS = [SEARCH_TOOL_DEFINITION, SAVE_INSTRUCTION_TOOL, SAVE_MEMORY_TOOL]


class MessageHandler:
    def __init__(
        self,
        bot: discord.Client,
        ai_client: AIClient,
        memory: ConversationMemory,
        persistent_memory: PersistentMemory,
    ):
        """メッセージハンドラを初期化。"""
        self.bot = bot
        self.ai_client = ai_client
        self.memory = memory
        self.persistent_memory = persistent_memory
        self.channel_message_counters: dict[int, int] = defaultdict(int)
        self.channel_last_spontaneous: dict[int, float] = defaultdict(float)
        self.channel_last_mention: dict[int, float] = defaultdict(float)
        self.mention_cooldown_seconds = 10  # メンション応答の最小間隔（秒）

    def _make_tool_executor(self, channel_id: int):
        """チャンネルに紐付いたツール実行関数を返すクロージャ。"""

        def executor(function_name: str, arguments: str) -> str:
            if function_name == "web_search":
                return execute_web_search(function_name, arguments)
            if function_name in ("save_custom_instruction", "save_important_memory"):
                return execute_memory_tool(function_name, arguments, self.persistent_memory, channel_id)
            return f"Unknown tool: {function_name}"

        return executor

    async def handle_message(self, message: discord.Message) -> None:
        """on_messageイベントから呼ばれるメインエントリーポイント。"""
        # ボット自身のメッセージは無視（Bot同士ループ防止）
        if message.author.bot:
            return

        config = get_config()

        # チャンネル制限チェック
        allowed = config.get("allowed_channels", [])
        if allowed and message.channel.id not in allowed:
            return

        # 会話履歴に追加
        self.memory.add_message(
            channel_id=message.channel.id,
            author=message.author.display_name,
            content=message.content,
            timestamp=message.created_at,
            author_id=message.author.id,
        )

        # メンション判定
        if self.bot.user and self.bot.user.mentioned_in(message):
            await self._handle_mention(message)
        else:
            await self._handle_spontaneous(message)

    async def _handle_mention(self, message: discord.Message) -> None:
        """メンション応答フロー。"""
        config = get_config()
        channel_id = message.channel.id

        # メンション応答のクールダウンチェック
        now = time.time()
        if now - self.channel_last_mention[channel_id] < self.mention_cooldown_seconds:
            return

        context_size = config["memory"]["context_size_mention"]

        try:
            system_prompt = self.persistent_memory.build_system_prompt(config["personality"], channel_id)
            async with message.channel.typing():
                api_messages = self.memory.format_for_api(channel_id, context_size)
                response = await asyncio.to_thread(
                    self.ai_client.generate_response,
                    system_prompt=system_prompt,
                    messages=api_messages,
                    tools=ALL_TOOLS,
                    tool_executor=self._make_tool_executor(channel_id),
                )

            if not response:
                return

            await self._send_response(message.channel, f"*[メンション]* {response}")
            self.channel_last_mention[channel_id] = time.time()

            # 応答を履歴に追加（ラベルなし）
            bot_name = self.bot.user.display_name if self.bot.user else "AI Assistant"
            bot_id = self.bot.user.id if self.bot.user else None
            self.memory.add_message(
                channel_id=channel_id,
                author=bot_name,
                content=response,
                timestamp=message.created_at,
                author_id=bot_id,
            )
        except Exception:
            logger.exception("メンション応答中にエラーが発生しました")

    async def _handle_spontaneous(self, message: discord.Message) -> None:
        """自発応答判定フロー。"""
        config = get_config()
        sp_config = config["spontaneous"]

        # 自発応答が無効
        if not sp_config["enabled"]:
            return

        # メッセージが短すぎる
        if len(message.content) < sp_config["min_message_length"]:
            return

        # メッセージカウンター
        channel_id = message.channel.id
        self.channel_message_counters[channel_id] += 1
        if self.channel_message_counters[channel_id] < sp_config["eval_interval"]:
            return

        # カウンターリセット
        self.channel_message_counters[channel_id] = 0

        # クールダウンチェック
        now = time.time()
        last = self.channel_last_spontaneous[channel_id]
        if now - last < sp_config["cooldown_seconds"]:
            return

        try:
            # 関連性評価
            context_size = config["memory"]["context_size_spontaneous"]
            api_messages = self.memory.format_for_api(channel_id, context_size)
            score = await asyncio.to_thread(
                self.ai_client.evaluate_relevance,
                messages=api_messages,
                bot_description=config["personality"],
            )

            logger.info("自発応答スコア: %.1f (閾値: %.1f) channel=%s", score, sp_config["threshold"], channel_id)

            if score < sp_config["threshold"]:
                return

            # 応答生成（自発応答ではツールなし、記憶の恩恵は受ける）
            system_prompt = self.persistent_memory.build_system_prompt(config["personality"], channel_id)
            allow_tools = bool(sp_config.get("allow_tools", False))
            async with message.channel.typing():
                if allow_tools:
                    response = await asyncio.to_thread(
                        self.ai_client.generate_response,
                        system_prompt=system_prompt,
                        messages=api_messages,
                        tools=ALL_TOOLS,
                        tool_executor=self._make_tool_executor(channel_id),
                    )
                else:
                    response = await asyncio.to_thread(
                        self.ai_client.generate_response,
                        system_prompt=system_prompt,
                        messages=api_messages,
                    )

            if not response:
                return

            await self._send_response(message.channel, f"*[自発]* {response}")

            # クールダウンタイマーリセット
            self.channel_last_spontaneous[channel_id] = time.time()

            # 応答を履歴に追加（ラベルなし）
            bot_name = self.bot.user.display_name if self.bot.user else "AI Assistant"
            bot_id = self.bot.user.id if self.bot.user else None
            self.memory.add_message(
                channel_id=channel_id,
                author=bot_name,
                content=response,
                timestamp=message.created_at,
                author_id=bot_id,
            )
        except Exception:
            logger.exception("自発応答処理中にエラーが発生しました")

    async def _send_response(self, channel: discord.TextChannel, content: str) -> None:
        """応答を送信する。2000文字超は分割して送信する。"""
        if not content or not content.strip():
            return

        if len(content) <= DISCORD_MAX_LENGTH:
            await channel.send(content)
            return

        # 分割送信
        remaining = content
        while remaining:
            if len(remaining) <= DISCORD_MAX_LENGTH:
                await channel.send(remaining)
                break

            # 改行位置で分割を試みる
            split_pos = remaining.rfind("\n", 0, DISCORD_MAX_LENGTH)
            if split_pos == -1:
                split_pos = DISCORD_MAX_LENGTH

            chunk = remaining[:split_pos]
            if chunk.strip():
                await channel.send(chunk)
            remaining = remaining[split_pos:].lstrip("\n")
