import json
import logging
from collections import defaultdict

logger = logging.getLogger(__name__)

SAVE_INSTRUCTION_TOOL = {
    "type": "function",
    "function": {
        "name": "save_custom_instruction",
        "description": (
            "ユーザーがボットの振る舞いを変更する指示をした時に使う。"
            "例: '関西弁で話して', '敬語で話して', 'もっと短く答えて', '英語で答えて'"
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "instruction": {
                    "type": "string",
                    "description": "保存するカスタム指示の内容",
                },
            },
            "required": ["instruction"],
        },
    },
}

SAVE_MEMORY_TOOL = {
    "type": "function",
    "function": {
        "name": "save_important_memory",
        "description": (
            "ユーザーが自分の好みや重要な情報を共有した時に使う。"
            "今後の会話で参考になる事実を保存する。"
            "例: 'Pythonが好き', 'エンジニアとして働いている', '猫を飼っている'"
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "memory": {
                    "type": "string",
                    "description": "記憶する重要な情報",
                },
            },
            "required": ["memory"],
        },
    },
}


class PersistentMemory:
    def __init__(self, max_instructions: int = 10, max_memories: int = 50):
        self.max_instructions = max_instructions
        self.max_memories = max_memories
        self._instructions: dict[int, list[str]] = defaultdict(list)
        self._memories: dict[int, list[str]] = defaultdict(list)

    def add_instruction(self, channel_id: int, instruction: str) -> str:
        """カスタム指示を追加。確認メッセージを返す。"""
        if not instruction or not instruction.strip():
            return "空の指示は保存できません"
        instructions = self._instructions[channel_id]
        if len(instructions) >= self.max_instructions:
            instructions.pop(0)
        instructions.append(instruction)
        logger.info("カスタム指示を保存: channel=%s, '%s'", channel_id, instruction)
        return f"カスタム指示を保存しました: {instruction}"

    def add_memory(self, channel_id: int, memory: str) -> str:
        """重要メモリを追加。確認メッセージを返す。"""
        if not memory or not memory.strip():
            return "空の情報は記憶できません"
        memories = self._memories[channel_id]
        if len(memories) >= self.max_memories:
            memories.pop(0)
        memories.append(memory)
        logger.info("重要メモリを保存: channel=%s, '%s'", channel_id, memory)
        return f"重要な情報を記憶しました: {memory}"

    def get_instructions(self, channel_id: int) -> list[str]:
        return list(self._instructions[channel_id])

    def get_memories(self, channel_id: int) -> list[str]:
        return list(self._memories[channel_id])

    def clear(self, channel_id: int) -> tuple[int, int]:
        """指定チャンネルの指示とメモリを全消去。(指示数, メモリ数)を返す。"""
        inst_count = len(self._instructions[channel_id])
        mem_count = len(self._memories[channel_id])
        self._instructions[channel_id].clear()
        self._memories[channel_id].clear()
        return inst_count, mem_count

    def build_system_prompt(self, base_personality: str, channel_id: int) -> str:
        """ベース性格 + カスタム指示 + 重要メモリを結合したシステムプロンプトを返す。"""
        parts = [base_personality.rstrip()]

        instructions = self.get_instructions(channel_id)
        if instructions:
            parts.append("\n## カスタム指示")
            parts.append("以下のユーザーからの指示に従ってください:")
            for inst in instructions:
                parts.append(f"- {inst}")

        memories = self.get_memories(channel_id)
        if memories:
            parts.append("\n## 記憶している情報")
            parts.append("以下の情報を覚えておいてください:")
            for mem in memories:
                parts.append(f"- {mem}")

        return "\n".join(parts)


def execute_memory_tool(function_name: str, arguments: str, persistent_memory: PersistentMemory, channel_id: int) -> str:
    """メモリ関連ツールを実行する。"""
    try:
        args = json.loads(arguments)
    except (json.JSONDecodeError, TypeError):
        logger.warning("メモリツールの引数パース失敗: %s", arguments)
        return "ツール引数のパースに失敗しました"
    if function_name == "save_custom_instruction":
        return persistent_memory.add_instruction(channel_id, args.get("instruction", ""))
    elif function_name == "save_important_memory":
        return persistent_memory.add_memory(channel_id, args.get("memory", ""))
    return f"Unknown memory tool: {function_name}"
