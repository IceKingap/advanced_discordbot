import os
import logging

import discord
from discord.ext import commands

from config import load_config, get_config
from conversation_memory import ConversationMemory
from ai_client import AIClient
from message_handler import MessageHandler
from persistent_memory import PersistentMemory


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    logger = logging.getLogger(__name__)

    config = load_config()

    intents = discord.Intents.default()
    intents.message_content = True
    intents.guilds = True

    bot = commands.Bot(command_prefix="!", intents=intents)

    memory = ConversationMemory(buffer_size=config["memory"]["buffer_size"])
    persistent_memory = PersistentMemory()
    ai_client = AIClient(
        api_key=os.environ["OPENAI_API_KEY"],
        model=config["openai"]["model"],
        max_tokens=config["openai"]["max_tokens"],
    )
    handler = MessageHandler(bot=bot, ai_client=ai_client, memory=memory, persistent_memory=persistent_memory)

    @bot.event
    async def on_ready():
        logger.info("Logged in as %s (ID: %s)", bot.user, bot.user.id)
        logger.info("Connected to %d guild(s)", len(bot.guilds))
        memory.bot_name = bot.user.display_name
        memory.bot_user_id = bot.user.id

    @bot.command(name="clear")
    async def clear_memory(ctx: commands.Context):
        """このチャンネルの会話履歴・カスタム指示・記憶を全消去する。"""
        conv_count = memory.clear(ctx.channel.id)
        inst_count, mem_count = persistent_memory.clear(ctx.channel.id)
        logger.info(
            "メモリを消去しました: channel=%s, 会話=%d件, 指示=%d件, 記憶=%d件",
            ctx.channel.id, conv_count, inst_count, mem_count,
        )
        await ctx.send(f"メモリを消去しました（会話: {conv_count}件、指示: {inst_count}件、記憶: {mem_count}件）")

    @bot.event
    async def on_message(message: discord.Message):
        await handler.handle_message(message)
        await bot.process_commands(message)

    bot.run(os.environ["DISCORD_TOKEN"], log_handler=None)


if __name__ == "__main__":
    main()
