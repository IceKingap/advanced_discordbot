import os
import sys
import unittest
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from conversation_memory import ConversationMemory


class TestConversationMemory(unittest.TestCase):
    def test_add_and_get_recent(self):
        mem = ConversationMemory(buffer_size=5)
        now = datetime.now()
        mem.add_message(1, "Alice", "Hello", now)
        mem.add_message(1, "Bob", "Hi there", now)

        recent = mem.get_recent(1, count=10)
        self.assertEqual(len(recent), 2)
        self.assertEqual(recent[0]["author"], "Alice")
        self.assertEqual(recent[1]["author"], "Bob")

    def test_buffer_size_limit(self):
        mem = ConversationMemory(buffer_size=3)
        now = datetime.now()
        for i in range(5):
            mem.add_message(1, f"User{i}", f"Message {i}", now)

        recent = mem.get_recent(1, count=10)
        self.assertEqual(len(recent), 3)
        self.assertEqual(recent[0]["author"], "User2")

    def test_get_recent_with_count(self):
        mem = ConversationMemory(buffer_size=10)
        now = datetime.now()
        for i in range(5):
            mem.add_message(1, f"User{i}", f"Msg {i}", now)

        recent = mem.get_recent(1, count=2)
        self.assertEqual(len(recent), 2)
        self.assertEqual(recent[0]["author"], "User3")
        self.assertEqual(recent[1]["author"], "User4")

    def test_separate_channels(self):
        mem = ConversationMemory(buffer_size=10)
        now = datetime.now()
        mem.add_message(1, "Alice", "Channel 1", now)
        mem.add_message(2, "Bob", "Channel 2", now)

        self.assertEqual(len(mem.get_recent(1)), 1)
        self.assertEqual(len(mem.get_recent(2)), 1)
        self.assertEqual(len(mem.get_recent(3)), 0)

    def test_format_for_api_user_messages(self):
        mem = ConversationMemory(buffer_size=10)
        now = datetime.now()
        mem.add_message(1, "Alice", "Hello", now)
        mem.add_message(1, "Bob", "Hi", now)

        api_msgs = mem.format_for_api(1, count=10)
        self.assertEqual(len(api_msgs), 2)
        self.assertEqual(api_msgs[0]["role"], "user")
        self.assertEqual(api_msgs[0]["content"], "Alice: Hello")

    def test_format_for_api_bot_messages(self):
        mem = ConversationMemory(buffer_size=10)
        mem.bot_name = "TestBot"
        now = datetime.now()
        mem.add_message(1, "Alice", "Hello", now)
        mem.add_message(1, "TestBot", "Hi! How can I help?", now)

        api_msgs = mem.format_for_api(1, count=10)
        self.assertEqual(api_msgs[0]["role"], "user")
        self.assertEqual(api_msgs[1]["role"], "assistant")
        self.assertEqual(api_msgs[1]["content"], "Hi! How can I help?")

    def test_format_for_api_bot_by_user_id(self):
        """bot_user_idでBot判定できることを確認"""
        mem = ConversationMemory(buffer_size=10)
        mem.bot_user_id = 12345
        now = datetime.now()
        mem.add_message(1, "Alice", "Hello", now, author_id=999)
        mem.add_message(1, "DifferentName", "Bot response", now, author_id=12345)

        api_msgs = mem.format_for_api(1, count=10)
        self.assertEqual(api_msgs[0]["role"], "user")
        self.assertEqual(api_msgs[1]["role"], "assistant")


if __name__ == "__main__":
    unittest.main()
