import os
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import web_search


class TestWebSearch(unittest.TestCase):
    @patch("web_search._fetch_page_text")
    @patch("web_search._run_ddgs_search")
    def test_quick_mode_does_not_fetch_page_content(self, mock_run_search, mock_fetch):
        mock_run_search.return_value = [
            {"title": "タイトル", "body": "短い説明", "href": "https://example.com/a"}
        ]

        result = web_search.web_search(
            query="テスト",
            mode="quick",
            category="text",
            settings={"max_results": 5, "max_pages": 3},
        )

        self.assertIn("スニペット: 短い説明", result)
        self.assertNotIn("本文抜粋:", result)
        mock_fetch.assert_not_called()

    @patch("web_search._fetch_page_text")
    @patch("web_search._run_ddgs_search")
    def test_normal_mode_fetches_page_content(self, mock_run_search, mock_fetch):
        mock_run_search.return_value = [
            {"title": "記事", "body": "説明", "href": "https://example.com/article"}
        ]
        mock_fetch.return_value = "取得できた本文"

        result = web_search.web_search(
            query="記事テスト",
            mode="normal",
            category="text",
            settings={
                "max_results": 5,
                "max_pages": 1,
                "max_chars_per_page": 1000,
                "max_total_chars": 2000,
            },
        )

        self.assertIn("本文抜粋: 取得できた本文", result)
        mock_fetch.assert_called_once()

    @patch("web_search._run_ddgs_search")
    def test_deep_mode_uses_expanded_queries(self, mock_run_search):
        def _fake_search(*, query, category, max_results, region, safesearch, timelimit):
            return [{"title": query, "body": "b", "href": f"https://example.com/{query}"}]

        mock_run_search.side_effect = _fake_search

        result = web_search.web_search(
            query="python 3.13",
            mode="deep",
            category="text",
            settings={"max_results": 3, "max_pages": 0, "deep_extra_queries": 2},
        )

        called_queries = [kwargs["query"] for _, kwargs in mock_run_search.call_args_list]
        self.assertEqual(len(called_queries), 3)
        self.assertIn("python 3.13", called_queries)
        self.assertIn("python 3.13 公式情報", called_queries)
        self.assertIn("python 3.13 詳細", called_queries)
        self.assertIn("ヒット件数: 3", result)

    @patch("web_search.web_search")
    @patch("web_search._load_search_config")
    def test_execute_tool_call_uses_config_defaults(self, mock_load_cfg, mock_web_search):
        mock_load_cfg.return_value = {
            "mode": "deep",
            "category": "news",
            "region": "wt-wt",
            "safesearch": "moderate",
            "timelimit": None,
            "max_results": 7,
            "max_pages": 2,
            "fetch_timeout_seconds": 6,
            "max_chars_per_page": 2500,
            "max_total_chars": 9000,
            "deep_extra_queries": 2,
        }
        mock_web_search.return_value = "ok"

        result = web_search.execute_tool_call("web_search", '{"query":"OpenAI"}')

        self.assertEqual(result, "ok")
        mock_web_search.assert_called_once_with(
            query="OpenAI",
            mode="deep",
            category="news",
            max_results=7,
            settings=mock_load_cfg.return_value,
        )

    def test_execute_tool_call_unknown(self):
        result = web_search.execute_tool_call("unknown_tool", "{}")
        self.assertEqual(result, "Unknown tool: unknown_tool")


if __name__ == "__main__":
    unittest.main()
