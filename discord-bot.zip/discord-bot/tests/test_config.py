import os
import sys
import unittest
import tempfile
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import config


class TestConfig(unittest.TestCase):
    def setUp(self):
        config._config = None
        self._orig_openai_model = os.environ.get("OPENAI_MODEL")
        os.environ["OPENAI_MODEL"] = ""

    def tearDown(self):
        if self._orig_openai_model is None:
            os.environ.pop("OPENAI_MODEL", None)
        else:
            os.environ["OPENAI_MODEL"] = self._orig_openai_model

    def test_deep_merge_basic(self):
        base = {"a": 1, "b": {"c": 2, "d": 3}}
        override = {"b": {"c": 99}, "e": 5}
        result = config._deep_merge(base, override)
        self.assertEqual(result["a"], 1)
        self.assertEqual(result["b"]["c"], 99)
        self.assertEqual(result["b"]["d"], 3)
        self.assertEqual(result["e"], 5)

    def test_load_config_with_defaults(self):
        os.environ["DISCORD_TOKEN"] = "test-token"
        os.environ["OPENAI_API_KEY"] = "test-key"
        try:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False, encoding="utf-8") as f:
                f.write("openai:\n  model: gpt-3.5-turbo\n")
                f.flush()
                cfg = config.load_config(f.name)

            self.assertEqual(cfg["openai"]["model"], "gpt-3.5-turbo")
            self.assertEqual(cfg["openai"]["max_tokens"], 500)  # default preserved
            self.assertEqual(cfg["memory"]["buffer_size"], 30)  # default preserved
        finally:
            os.unlink(f.name)
            os.environ.pop("DISCORD_TOKEN", None)
            os.environ.pop("OPENAI_API_KEY", None)

    def test_load_config_openai_model_env_override(self):
        os.environ["DISCORD_TOKEN"] = "test-token"
        os.environ["OPENAI_API_KEY"] = "test-key"
        os.environ["OPENAI_MODEL"] = "gpt-4.1-mini"
        try:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False, encoding="utf-8") as f:
                f.write("openai:\n  model: gpt-4o\n")
                f.flush()
                cfg = config.load_config(f.name)

            self.assertEqual(cfg["openai"]["model"], "gpt-4.1-mini")
        finally:
            os.unlink(f.name)
            os.environ.pop("DISCORD_TOKEN", None)
            os.environ.pop("OPENAI_API_KEY", None)
            os.environ.pop("OPENAI_MODEL", None)

    @patch("config.load_dotenv")
    def test_load_config_missing_token_raises(self, mock_dotenv):
        os.environ.pop("DISCORD_TOKEN", None)
        os.environ.pop("OPENAI_API_KEY", None)
        with self.assertRaises(ValueError):
            config.load_config("nonexistent.yaml")

    def test_get_config_before_load_raises(self):
        with self.assertRaises(RuntimeError):
            config.get_config()

    def test_get_config_after_load(self):
        os.environ["DISCORD_TOKEN"] = "test-token"
        os.environ["OPENAI_API_KEY"] = "test-key"
        try:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False, encoding="utf-8") as f:
                f.write("{}\n")
                f.flush()
                config.load_config(f.name)
            cfg = config.get_config()
            self.assertIsInstance(cfg, dict)
            self.assertIn("personality", cfg)
        finally:
            os.unlink(f.name)
            os.environ.pop("DISCORD_TOKEN", None)
            os.environ.pop("OPENAI_API_KEY", None)


if __name__ == "__main__":
    unittest.main()
