import os
import sys
import unittest
from types import SimpleNamespace
from unittest.mock import call, patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import ai_client
from ai_client import AIClient


def make_response(content: str, model: str = "gpt-4o", tool_calls=None, finish_reason="stop"):
    return SimpleNamespace(
        model=model,
        choices=[SimpleNamespace(
            message=SimpleNamespace(content=content, tool_calls=tool_calls),
            finish_reason=finish_reason,
        )],
        usage=SimpleNamespace(prompt_tokens=10, completion_tokens=20, total_tokens=30),
    )


class DummyRateLimitError(Exception):
    pass


class DummyBadRequestError(Exception):
    pass


class TestAIClient(unittest.TestCase):
    @patch("ai_client.OpenAI")
    def test_generate_response_success(self, mock_openai_cls):
        mock_sdk_client = mock_openai_cls.return_value
        mock_sdk_client.chat.completions.create.return_value = make_response("こんにちは")

        client = AIClient(api_key="test-key")
        result = client.generate_response(
            system_prompt="あなたは親切なAIです",
            messages=[{"role": "user", "content": "テスト"}],
        )

        self.assertEqual(result, "こんにちは")
        kwargs = mock_sdk_client.chat.completions.create.call_args.kwargs
        self.assertEqual(kwargs["model"], "gpt-4o")
        self.assertEqual(kwargs["max_tokens"], 500)
        self.assertEqual(kwargs["messages"][0]["role"], "system")

    @patch("ai_client.OpenAI")
    def test_generate_response_switches_to_max_completion_tokens_on_unsupported_max_tokens(self, mock_openai_cls):
        mock_sdk_client = mock_openai_cls.return_value

        with patch.object(ai_client.openai, "BadRequestError", DummyBadRequestError):
            mock_sdk_client.chat.completions.create.side_effect = [
                DummyBadRequestError(
                    "Error code: 400 - {'error': {'message': \"Unsupported parameter: "
                    "'max_tokens' is not supported with this model. Use "
                    "'max_completion_tokens' instead.\"}}"
                ),
                make_response("切替成功"),
            ]

            client = AIClient(api_key="test-key", model="gpt-5-mini")
            result = client.generate_response(
                system_prompt="sys",
                messages=[{"role": "user", "content": "hello"}],
            )

        self.assertEqual(result, "切替成功")
        self.assertEqual(mock_sdk_client.chat.completions.create.call_count, 2)
        first_kwargs = mock_sdk_client.chat.completions.create.call_args_list[0].kwargs
        second_kwargs = mock_sdk_client.chat.completions.create.call_args_list[1].kwargs
        self.assertIn("max_tokens", first_kwargs)
        self.assertNotIn("max_completion_tokens", first_kwargs)
        self.assertIn("max_completion_tokens", second_kwargs)
        self.assertNotIn("max_tokens", second_kwargs)

    @patch("ai_client.time.sleep")
    @patch("ai_client.OpenAI")
    def test_generate_response_retry_success(self, mock_openai_cls, mock_sleep):
        mock_sdk_client = mock_openai_cls.return_value

        with patch.object(ai_client.openai, "RateLimitError", DummyRateLimitError):
            mock_sdk_client.chat.completions.create.side_effect = [
                DummyRateLimitError("rate limited"),
                make_response("リトライ後成功"),
            ]

            client = AIClient(api_key="test-key")
            result = client.generate_response(
                system_prompt="sys",
                messages=[{"role": "user", "content": "hello"}],
            )

        self.assertEqual(result, "リトライ後成功")
        self.assertEqual(mock_sdk_client.chat.completions.create.call_count, 2)
        mock_sleep.assert_called_once_with(1)

    @patch("ai_client.time.sleep")
    @patch("ai_client.OpenAI")
    def test_generate_response_retry_failure(self, mock_openai_cls, mock_sleep):
        mock_sdk_client = mock_openai_cls.return_value

        with patch.object(ai_client.openai, "RateLimitError", DummyRateLimitError):
            mock_sdk_client.chat.completions.create.side_effect = [
                DummyRateLimitError("fail1"),
                DummyRateLimitError("fail2"),
                DummyRateLimitError("fail3"),
                DummyRateLimitError("fail4"),
            ]

            client = AIClient(api_key="test-key")
            with self.assertRaises(DummyRateLimitError):
                client.generate_response(
                    system_prompt="sys",
                    messages=[{"role": "user", "content": "hello"}],
                )

        self.assertEqual(mock_sdk_client.chat.completions.create.call_count, 4)
        self.assertEqual(mock_sleep.call_args_list, [call(1), call(2), call(4)])

    @patch("ai_client.OpenAI")
    def test_generate_response_with_tool_executor(self, mock_openai_cls):
        mock_sdk_client = mock_openai_cls.return_value

        tool_call = SimpleNamespace(
            id="call_123",
            function=SimpleNamespace(name="my_tool", arguments='{"q": "test"}'),
        )
        # 1回目: ツール呼び出し、2回目: 最終応答
        mock_sdk_client.chat.completions.create.side_effect = [
            make_response(None, tool_calls=[tool_call], finish_reason="tool_calls"),
            make_response("ツール結果を使った回答"),
        ]

        executor_called = []

        def fake_executor(name, args):
            executor_called.append((name, args))
            return "tool result"

        client = AIClient(api_key="test-key")
        result = client.generate_response(
            system_prompt="sys",
            messages=[{"role": "user", "content": "hello"}],
            tools=[{"type": "function", "function": {"name": "my_tool"}}],
            tool_executor=fake_executor,
        )

        self.assertEqual(result, "ツール結果を使った回答")
        self.assertEqual(len(executor_called), 1)
        self.assertEqual(executor_called[0][0], "my_tool")
        self.assertEqual(executor_called[0][1], '{"q": "test"}')

        # 2回目のAPI呼び出しにtoolメッセージが含まれることを確認
        second_call_msgs = mock_sdk_client.chat.completions.create.call_args_list[1].kwargs["messages"]
        tool_msg = [m for m in second_call_msgs if isinstance(m, dict) and m.get("role") == "tool"]
        self.assertEqual(len(tool_msg), 1)
        self.assertEqual(tool_msg[0]["content"], "tool result")

    @patch("ai_client.OpenAI")
    def test_evaluate_relevance_success(self, mock_openai_cls):
        mock_sdk_client = mock_openai_cls.return_value
        mock_sdk_client.chat.completions.create.return_value = make_response("8.5")

        client = AIClient(api_key="test-key")
        score = client.evaluate_relevance(
            messages=[{"role": "user", "content": "エラーの直し方を教えて"}],
            bot_description="Pythonの質問に答えるボット",
        )

        self.assertEqual(score, 8.5)

    @patch("ai_client.OpenAI")
    def test_evaluate_relevance_parse_failure_returns_zero(self, mock_openai_cls):
        mock_sdk_client = mock_openai_cls.return_value
        mock_sdk_client.chat.completions.create.return_value = make_response("わかりません")

        client = AIClient(api_key="test-key")
        score = client.evaluate_relevance(
            messages=[{"role": "user", "content": "雑談しよう"}],
            bot_description="雑談には参加しないボット",
        )

        self.assertEqual(score, 0.0)


if __name__ == "__main__":
    unittest.main()
