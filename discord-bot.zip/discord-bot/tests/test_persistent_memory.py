import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from persistent_memory import PersistentMemory, execute_memory_tool


class TestPersistentMemory(unittest.TestCase):
    def test_add_and_get_instructions(self):
        pm = PersistentMemory()
        pm.add_instruction(1, "関西弁で話して")
        self.assertEqual(pm.get_instructions(1), ["関西弁で話して"])
        self.assertEqual(pm.get_instructions(2), [])

    def test_add_and_get_memories(self):
        pm = PersistentMemory()
        pm.add_memory(1, "Pythonが好き")
        self.assertEqual(pm.get_memories(1), ["Pythonが好き"])
        self.assertEqual(pm.get_memories(2), [])

    def test_instruction_limit(self):
        pm = PersistentMemory(max_instructions=3)
        for i in range(5):
            pm.add_instruction(1, f"指示{i}")
        self.assertEqual(len(pm.get_instructions(1)), 3)
        self.assertEqual(pm.get_instructions(1)[0], "指示2")

    def test_memory_limit(self):
        pm = PersistentMemory(max_memories=3)
        for i in range(5):
            pm.add_memory(1, f"記憶{i}")
        self.assertEqual(len(pm.get_memories(1)), 3)
        self.assertEqual(pm.get_memories(1)[0], "記憶2")

    def test_clear(self):
        pm = PersistentMemory()
        pm.add_instruction(1, "指示A")
        pm.add_memory(1, "記憶A")
        pm.add_memory(1, "記憶B")
        inst_count, mem_count = pm.clear(1)
        self.assertEqual(inst_count, 1)
        self.assertEqual(mem_count, 2)
        self.assertEqual(pm.get_instructions(1), [])
        self.assertEqual(pm.get_memories(1), [])

    def test_clear_empty(self):
        pm = PersistentMemory()
        inst_count, mem_count = pm.clear(999)
        self.assertEqual(inst_count, 0)
        self.assertEqual(mem_count, 0)

    def test_build_system_prompt_empty(self):
        pm = PersistentMemory()
        result = pm.build_system_prompt("ベース性格", 1)
        self.assertEqual(result, "ベース性格")

    def test_build_system_prompt_with_instructions(self):
        pm = PersistentMemory()
        pm.add_instruction(1, "関西弁で話して")
        result = pm.build_system_prompt("ベース性格", 1)
        self.assertIn("ベース性格", result)
        self.assertIn("カスタム指示", result)
        self.assertIn("関西弁で話して", result)

    def test_build_system_prompt_with_all(self):
        pm = PersistentMemory()
        pm.add_instruction(1, "敬語で話して")
        pm.add_memory(1, "Pythonが好き")
        result = pm.build_system_prompt("ベース性格", 1)
        self.assertIn("ベース性格", result)
        self.assertIn("敬語で話して", result)
        self.assertIn("Pythonが好き", result)
        self.assertIn("カスタム指示", result)
        self.assertIn("記憶している情報", result)

    def test_separate_channels(self):
        pm = PersistentMemory()
        pm.add_instruction(1, "指示A")
        pm.add_instruction(2, "指示B")
        pm.add_memory(1, "記憶A")
        self.assertEqual(pm.get_instructions(1), ["指示A"])
        self.assertEqual(pm.get_instructions(2), ["指示B"])
        self.assertEqual(pm.get_memories(2), [])

    def test_execute_memory_tool_instruction(self):
        pm = PersistentMemory()
        result = execute_memory_tool(
            "save_custom_instruction",
            '{"instruction": "関西弁で話して"}',
            pm, 1,
        )
        self.assertIn("関西弁で話して", result)
        self.assertEqual(pm.get_instructions(1), ["関西弁で話して"])

    def test_execute_memory_tool_memory(self):
        pm = PersistentMemory()
        result = execute_memory_tool(
            "save_important_memory",
            '{"memory": "猫を飼っている"}',
            pm, 1,
        )
        self.assertIn("猫を飼っている", result)
        self.assertEqual(pm.get_memories(1), ["猫を飼っている"])


    def test_empty_instruction_rejected(self):
        pm = PersistentMemory()
        result = pm.add_instruction(1, "")
        self.assertIn("空", result)
        self.assertEqual(pm.get_instructions(1), [])

    def test_empty_memory_rejected(self):
        pm = PersistentMemory()
        result = pm.add_memory(1, "  ")
        self.assertIn("空", result)
        self.assertEqual(pm.get_memories(1), [])

    def test_execute_memory_tool_invalid_json(self):
        pm = PersistentMemory()
        result = execute_memory_tool("save_custom_instruction", "not json", pm, 1)
        self.assertIn("パース", result)
        self.assertEqual(pm.get_instructions(1), [])


if __name__ == "__main__":
    unittest.main()
