import os
import sys
import time
import asyncio
import unittest
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from message_handler import MessageHandler, DISCORD_MAX_LENGTH


def make_config(
    spontaneous_enabled=True,
    threshold=7.0,
    cooldown=300,
    eval_interval=5,
    min_length=6,
    allow_tools=False,
):
    return {
        "personality": "テスト用AI",
        "openai": {"model": "gpt-4o", "max_tokens": 500},
        "spontaneous": {
            "enabled": spontaneous_enabled,
            "threshold": threshold,
            "cooldown_seconds": cooldown,
            "eval_interval": eval_interval,
            "min_message_length": min_length,
            "allow_tools": allow_tools,
        },
        "memory": {
            "buffer_size": 30,
            "context_size_mention": 10,
            "context_size_spontaneous": 20,
        },
        "allowed_channels": [],
    }


def make_message(content="テストメッセージ", is_bot=False, channel_id=123):
    message = MagicMock()
    message.author.bot = is_bot
    message.author.display_name = "TestUser"
    message.author.id = 999
    message.content = content
    message.channel.id = channel_id
    message.channel.send = AsyncMock()
    message.channel.typing = MagicMock(return_value=AsyncContextManager())
    message.created_at = datetime.now()
    return message


class AsyncContextManager:
    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass


async def fake_to_thread(func, *args, **kwargs):
    """asyncio.to_threadの代替: 同期関数をそのまま呼ぶ"""
    return func(*args, **kwargs)


def make_handler():
    bot = MagicMock()
    bot.user = MagicMock()
    bot.user.display_name = "TestBot"
    bot.user.id = 12345
    bot.user.mentioned_in = MagicMock(return_value=False)

    ai_client = MagicMock()
    ai_client.generate_response = MagicMock(return_value="応答テスト")
    ai_client.evaluate_relevance = MagicMock(return_value=5.0)

    from conversation_memory import ConversationMemory
    from persistent_memory import PersistentMemory
    memory = ConversationMemory(buffer_size=30)
    persistent_memory = PersistentMemory()

    handler = MessageHandler(bot=bot, ai_client=ai_client, memory=memory, persistent_memory=persistent_memory)
    return handler, bot, ai_client, memory


class TestMessageHandler(unittest.TestCase):

    @patch("message_handler.get_config")
    def test_ignore_bot_messages(self, mock_get_config):
        mock_get_config.return_value = make_config()
        handler, bot, ai_client, memory = make_handler()
        msg = make_message(is_bot=True)

        asyncio.run(handler.handle_message(msg))

        ai_client.generate_response.assert_not_called()

    @patch("message_handler.asyncio.to_thread", side_effect=fake_to_thread)
    @patch("message_handler.get_config")
    def test_mention_response(self, mock_get_config, mock_to_thread):
        mock_get_config.return_value = make_config()
        handler, bot, ai_client, memory = make_handler()

        msg = make_message(content="@bot こんにちは")
        bot.user.mentioned_in.return_value = True

        asyncio.run(handler.handle_message(msg))

        ai_client.generate_response.assert_called_once()
        # tools と tool_executor が渡されていることを確認
        call_kwargs = ai_client.generate_response.call_args.kwargs
        self.assertIsNotNone(call_kwargs.get("tools"))
        self.assertEqual(len(call_kwargs["tools"]), 3)  # web_search + 2 memory tools
        self.assertIsNotNone(call_kwargs.get("tool_executor"))
        # ラベル付きで送信されることを確認
        msg.channel.send.assert_called_once_with("*[メンション]* 応答テスト")

    @patch("message_handler.get_config")
    def test_spontaneous_disabled(self, mock_get_config):
        mock_get_config.return_value = make_config(spontaneous_enabled=False)
        handler, bot, ai_client, memory = make_handler()

        msg = make_message(content="これは長いテストメッセージです")

        asyncio.run(handler.handle_message(msg))

        ai_client.evaluate_relevance.assert_not_called()

    @patch("message_handler.get_config")
    def test_spontaneous_short_message_ignored(self, mock_get_config):
        mock_get_config.return_value = make_config(min_length=20)
        handler, bot, ai_client, memory = make_handler()

        msg = make_message(content="短い")

        asyncio.run(handler.handle_message(msg))

        ai_client.evaluate_relevance.assert_not_called()

    @patch("message_handler.asyncio.to_thread", side_effect=fake_to_thread)
    @patch("message_handler.get_config")
    def test_spontaneous_counter_increment(self, mock_get_config, mock_to_thread):
        mock_get_config.return_value = make_config(eval_interval=3)
        handler, bot, ai_client, memory = make_handler()

        # 1st and 2nd message: counter increments, no evaluation
        for _ in range(2):
            msg = make_message(content="テストメッセージです")
            asyncio.run(handler.handle_message(msg))

        ai_client.evaluate_relevance.assert_not_called()

        # 3rd message: counter reaches interval, evaluation triggered
        msg = make_message(content="テストメッセージです")
        asyncio.run(handler.handle_message(msg))

        ai_client.evaluate_relevance.assert_called_once()

    @patch("message_handler.asyncio.to_thread", side_effect=fake_to_thread)
    @patch("message_handler.get_config")
    def test_spontaneous_below_threshold(self, mock_get_config, mock_to_thread):
        mock_get_config.return_value = make_config(eval_interval=1, threshold=8.0)
        handler, bot, ai_client, memory = make_handler()
        ai_client.evaluate_relevance.return_value = 5.0

        msg = make_message(content="テストメッセージです")

        asyncio.run(handler.handle_message(msg))

        ai_client.evaluate_relevance.assert_called_once()
        ai_client.generate_response.assert_not_called()

    @patch("message_handler.asyncio.to_thread", side_effect=fake_to_thread)
    @patch("message_handler.get_config")
    def test_spontaneous_above_threshold(self, mock_get_config, mock_to_thread):
        mock_get_config.return_value = make_config(eval_interval=1, threshold=3.0, cooldown=0)
        handler, bot, ai_client, memory = make_handler()
        ai_client.evaluate_relevance.return_value = 8.0

        msg = make_message(content="テストメッセージです")

        asyncio.run(handler.handle_message(msg))

        ai_client.generate_response.assert_called_once()
        # 自発応答ではツールなしであることを確認
        call_kwargs = ai_client.generate_response.call_args.kwargs
        self.assertIsNone(call_kwargs.get("tools"))
        # ラベル付きで送信されることを確認
        msg.channel.send.assert_called_once_with("*[自発]* 応答テスト")

    @patch("message_handler.asyncio.to_thread", side_effect=fake_to_thread)
    @patch("message_handler.get_config")
    def test_spontaneous_above_threshold_with_tools(self, mock_get_config, mock_to_thread):
        mock_get_config.return_value = make_config(
            eval_interval=1,
            threshold=3.0,
            cooldown=0,
            allow_tools=True,
        )
        handler, bot, ai_client, memory = make_handler()
        ai_client.evaluate_relevance.return_value = 8.0

        msg = make_message(content="最新情報を調べたい")

        asyncio.run(handler.handle_message(msg))

        ai_client.generate_response.assert_called_once()
        call_kwargs = ai_client.generate_response.call_args.kwargs
        self.assertIsNotNone(call_kwargs.get("tools"))
        self.assertEqual(len(call_kwargs["tools"]), 3)
        self.assertIsNotNone(call_kwargs.get("tool_executor"))
        msg.channel.send.assert_called_once_with("*[自発]* 応答テスト")

    @patch("message_handler.get_config")
    def test_cooldown_prevents_spontaneous(self, mock_get_config):
        mock_get_config.return_value = make_config(eval_interval=1, threshold=1.0, cooldown=9999)
        handler, bot, ai_client, memory = make_handler()
        ai_client.evaluate_relevance.return_value = 10.0

        # Set last spontaneous to now (within cooldown)
        handler.channel_last_spontaneous[123] = time.time()

        msg = make_message(content="テストメッセージです")

        asyncio.run(handler.handle_message(msg))

        ai_client.evaluate_relevance.assert_not_called()

    @patch("message_handler.asyncio.to_thread", side_effect=fake_to_thread)
    @patch("message_handler.get_config")
    def test_mention_cooldown(self, mock_get_config, mock_to_thread):
        mock_get_config.return_value = make_config()
        handler, bot, ai_client, memory = make_handler()
        bot.user.mentioned_in.return_value = True

        # First mention: should respond
        msg = make_message(content="@bot hello")
        asyncio.run(handler.handle_message(msg))
        self.assertEqual(ai_client.generate_response.call_count, 1)

        # Second mention immediately: should be blocked by cooldown
        msg2 = make_message(content="@bot again")
        asyncio.run(handler.handle_message(msg2))
        self.assertEqual(ai_client.generate_response.call_count, 1)  # still 1

    def test_empty_response_not_sent(self):
        handler, _, _, _ = make_handler()
        channel = MagicMock()
        channel.send = AsyncMock()

        asyncio.run(handler._send_response(channel, ""))
        channel.send.assert_not_called()

        asyncio.run(handler._send_response(channel, "   "))
        channel.send.assert_not_called()


class TestSendResponse(unittest.TestCase):
    def test_short_message(self):
        handler, _, _, _ = make_handler()
        channel = MagicMock()
        channel.send = AsyncMock()

        asyncio.run(handler._send_response(channel, "短いメッセージ"))

        channel.send.assert_called_once_with("短いメッセージ")

    def test_long_message_split(self):
        handler, _, _, _ = make_handler()
        channel = MagicMock()
        channel.send = AsyncMock()

        # 2000文字超のメッセージ
        long_msg = "あ" * 1500 + "\n" + "い" * 1500

        asyncio.run(handler._send_response(channel, long_msg))

        self.assertEqual(channel.send.call_count, 2)


if __name__ == "__main__":
    unittest.main()
